import { Card } from "@/components/ui/card";

interface SystemStatusProps {
  isOnline: boolean;
}

export default function SystemStatus({ isOnline }: SystemStatusProps) {
  const statusItems = [
    {
      label: 'Translation API',
      status: isOnline ? 'Active' : 'Offline',
      color: isOnline ? 'healthcare-green' : 'medical-red',
    },
    {
      label: 'Speech Recognition',
      status: isOnline ? 'Ready' : 'Offline',
      color: isOnline ? 'healthcare-green' : 'medical-red',
    },
    {
      label: 'Text-to-Speech',
      status: 'Ready', // TTS works offline
      color: 'healthcare-green',
    },
    {
      label: 'Offline Cache',
      status: '256 phrases',
      color: 'urgent-orange',
    },
  ];

  return (
    <Card className="p-6">
      <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
        <i className="fas fa-info-circle text-medical-blue mr-2"></i>
        System Status
      </h2>
      
      <div className="space-y-3">
        {statusItems.map((item, index) => (
          <div key={index} className="flex items-center justify-between">
            <span className="text-sm text-gray-600">{item.label}</span>
            <div className="flex items-center space-x-2">
              <div className={`w-2 h-2 bg-${item.color} rounded-full`}></div>
              <span className={`text-sm text-${item.color}`}>{item.status}</span>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}
