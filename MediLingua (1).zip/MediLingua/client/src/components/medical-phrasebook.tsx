import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useTextToSpeech } from "@/hooks/use-text-to-speech";
import { apiRequest } from "@/lib/queryClient";

interface MedicalPhrasebookProps {
  sessionId: string;
}

const categories = [
  { key: 'Emergency', label: 'Emergency', icon: 'fas fa-exclamation-triangle' },
  { key: 'Diagnosis', label: 'Diagnosis', icon: 'fas fa-stethoscope' },
  { key: 'Symptoms', label: 'Symptoms', icon: 'fas fa-thermometer-half' },
  { key: 'Consent', label: 'Consent', icon: 'fas fa-file-signature' },
];

export default function MedicalPhrasebook({ sessionId }: MedicalPhrasebookProps) {
  const [selectedCategory, setSelectedCategory] = useState('Emergency');
  const { toast } = useToast();
  const { speak } = useTextToSpeech();
  const queryClient = useQueryClient();

  const { data: phrases, isLoading } = useQuery({
    queryKey: ['/api/phrases'],
    staleTime: Infinity, // Phrases are static
  });

  const translatePhraseMutation = useMutation({
    mutationFn: async (data: { text: string; sourceLanguage: string; targetLanguage: string }) => {
      const response = await apiRequest('POST', '/api/translate', data);
      return await response.json();
    },
    onSuccess: async (data) => {
      // Save to conversation history
      await apiRequest('POST', '/api/conversation', {
        originalText: data.originalText,
        translatedText: data.translatedText,
        sourceLanguage: data.sourceLanguage,
        targetLanguage: data.targetLanguage,
        speaker: 'provider',
        sessionId,
      });
      
      queryClient.invalidateQueries({ queryKey: ['/api/conversation'] });
      
      // Speak the translation
      speak(data.translatedText, data.targetLanguage);
      
      toast({
        title: "Phrase Translated",
        description: "Quick phrase translation complete.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Translation Failed", 
        description: "Using offline mode - phrase spoken in original language.",
        variant: "destructive",
      });
    },
  });

  const handleTranslateAndSpeak = (phrase: string) => {
    // Default to English -> Spanish for quick phrases
    translatePhraseMutation.mutate({
      text: phrase,
      sourceLanguage: 'en',
      targetLanguage: 'es',
    });
  };

  const handleInsertPhrase = (phrase: string) => {
    // This would typically set the phrase in the main translation interface
    // For now, we'll show a toast with copy functionality
    navigator.clipboard.writeText(phrase);
    toast({
      title: "Phrase Copied",
      description: "Phrase copied to clipboard and ready to translate.",
    });
  };

  const currentPhrases = phrases?.[selectedCategory] || [];

  return (
    <Card className="p-6">
      <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
        <i className="fas fa-book-medical text-medical-blue mr-2"></i>
        Medical Phrasebook
      </h2>
      
      {/* Category Tabs */}
      <div className="border-b border-gray-200 mb-4">
        <nav className="-mb-px flex space-x-1">
          {categories.map((category) => (
            <Button
              key={category.key}
              variant="ghost"
              size="sm"
              className={`py-2 px-3 border-b-2 font-medium text-sm ${
                selectedCategory === category.key
                  ? 'border-medical-blue text-medical-blue'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
              onClick={() => setSelectedCategory(category.key)}
            >
              {category.label}
            </Button>
          ))}
        </nav>
      </div>

      {/* Phrase List */}
      <div className="space-y-2 max-h-64 overflow-y-auto">
        {isLoading ? (
          <div className="text-center py-4 text-gray-500">Loading phrases...</div>
        ) : currentPhrases.length > 0 ? (
          currentPhrases.map((phrase: string, index: number) => (
            <div
              key={index}
              className="w-full text-left p-3 rounded-md border border-gray-200 hover:bg-gray-50 hover:border-medical-blue transition-colors group"
            >
              <div className="flex items-center justify-between">
                <span className="text-gray-900">{phrase}</span>
                <div className="flex space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Button
                    size="sm"
                    variant="ghost"
                    className="text-medical-blue hover:text-blue-700 p-1"
                    onClick={() => handleTranslateAndSpeak(phrase)}
                    disabled={translatePhraseMutation.isPending}
                  >
                    <i className="fas fa-volume-up text-sm"></i>
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="text-medical-blue hover:text-blue-700 p-1"
                    onClick={() => handleInsertPhrase(phrase)}
                  >
                    <i className="fas fa-plus text-sm"></i>
                  </Button>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-4 text-gray-500">No phrases available</div>
        )}
      </div>
    </Card>
  );
}
