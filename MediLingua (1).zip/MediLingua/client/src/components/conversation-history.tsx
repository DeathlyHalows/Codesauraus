import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { formatDistanceToNow } from "date-fns";

interface ConversationHistoryProps {
  sessionId: string;
}

export default function ConversationHistory({ sessionId }: ConversationHistoryProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: conversationHistory, isLoading } = useQuery({
    queryKey: ['/api/conversation', { sessionId }],
    refetchInterval: 5000, // Refresh every 5 seconds
  });

  const clearHistoryMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('DELETE', `/api/conversation?sessionId=${sessionId}`);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/conversation'] });
      toast({
        title: "History Cleared",
        description: "Conversation history has been cleared.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to clear conversation history.",
        variant: "destructive",
      });
    },
  });

  const handleClearHistory = () => {
    clearHistoryMutation.mutate();
  };

  return (
    <Card className="p-6">
      <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
        <i className="fas fa-history text-medical-blue mr-2"></i>
        Conversation History
      </h2>
      
      <div className="space-y-3 max-h-64 overflow-y-auto">
        {isLoading ? (
          <div className="text-center py-4 text-gray-500">Loading history...</div>
        ) : conversationHistory && conversationHistory.length > 0 ? (
          conversationHistory.map((entry: any) => (
            <div key={entry.id} className="bg-gray-50 rounded-lg p-3">
              <div className="text-sm text-gray-600 mb-1">
                {entry.speaker === 'provider' ? 'Provider' : 'Patient'} ({entry.sourceLanguage.toUpperCase()} → {entry.targetLanguage.toUpperCase()})
              </div>
              <div className="text-gray-900 mb-2">{entry.originalText}</div>
              <div className="text-medical-blue font-medium">{entry.translatedText}</div>
              <div className="text-xs text-gray-500 mt-1">
                {formatDistanceToNow(new Date(entry.timestamp), { addSuffix: true })}
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-4 text-gray-500">No conversation history yet</div>
        )}
      </div>
      
      {conversationHistory && conversationHistory.length > 0 && (
        <Button
          className="w-full mt-4 bg-medical-gray text-white hover:bg-gray-600"
          onClick={handleClearHistory}
          disabled={clearHistoryMutation.isPending}
        >
          {clearHistoryMutation.isPending ? 'Clearing...' : 'Clear History'}
        </Button>
      )}
    </Card>
  );
}
