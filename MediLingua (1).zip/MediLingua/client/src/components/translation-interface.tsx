import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useSpeechRecognition } from "@/hooks/use-speech-recognition";
import { useTextToSpeech } from "@/hooks/use-text-to-speech";
import { apiRequest } from "@/lib/queryClient";

interface TranslationInterfaceProps {
  sessionId: string;
  isOnline: boolean;
}

const languages = [
  { code: 'en', name: 'English' },
  { code: 'es', name: 'Spanish' },
  { code: 'fr', name: 'French' },
  { code: 'de', name: 'German' },
  { code: 'zh', name: 'Chinese' },
];

export default function TranslationInterface({ sessionId, isOnline }: TranslationInterfaceProps) {
  const [sourceLanguage, setSourceLanguage] = useState('en');
  const [targetLanguage, setTargetLanguage] = useState('es');
  const [inputText, setInputText] = useState('');
  const [translatedText, setTranslatedText] = useState('');
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const { isListening, startListening, stopListening, transcript } = useSpeechRecognition(sourceLanguage);
  const { speak, isSpeaking } = useTextToSpeech();

  // Update input text when speech recognition provides transcript
  useState(() => {
    if (transcript) {
      setInputText(transcript);
    }
  }, [transcript]);

  const translateMutation = useMutation({
    mutationFn: async (data: { text: string; sourceLanguage: string; targetLanguage: string }) => {
      const response = await apiRequest('POST', '/api/translate', data);
      return await response.json();
    },
    onSuccess: async (data) => {
      setTranslatedText(data.translatedText);
      
      // Save to conversation history
      await apiRequest('POST', '/api/conversation', {
        originalText: data.originalText,
        translatedText: data.translatedText,
        sourceLanguage: data.sourceLanguage,
        targetLanguage: data.targetLanguage,
        speaker: 'provider',
        sessionId,
      });
      
      queryClient.invalidateQueries({ queryKey: ['/api/conversation'] });
      
      toast({
        title: "Translation Complete",
        description: "Medical terminology verified and translation ready.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Translation Failed",
        description: error.message || "Please check your internet connection and try again.",
        variant: "destructive",
      });
    },
  });

  const handleTranslate = () => {
    if (!inputText.trim()) {
      toast({
        title: "No Text to Translate",
        description: "Please enter text or use speech input.",
        variant: "destructive",
      });
      return;
    }

    if (!isOnline) {
      toast({
        title: "Offline Mode",
        description: "Translation services unavailable. Use the phrasebook for offline phrases.",
        variant: "destructive",
      });
      return;
    }

    translateMutation.mutate({
      text: inputText,
      sourceLanguage,
      targetLanguage,
    });
  };

  const handleSwapLanguages = () => {
    setSourceLanguage(targetLanguage);
    setTargetLanguage(sourceLanguage);
    setInputText(translatedText);
    setTranslatedText(inputText);
  };

  const handleSpeechToggle = () => {
    if (isListening) {
      stopListening();
    } else {
      startListening();
    }
  };

  const handleSpeak = () => {
    if (translatedText) {
      speak(translatedText, targetLanguage);
    }
  };

  const handleClear = () => {
    setInputText('');
    setTranslatedText('');
  };

  const handleCopy = async () => {
    if (translatedText) {
      await navigator.clipboard.writeText(translatedText);
      toast({
        title: "Copied to Clipboard",
        description: "Translation copied successfully.",
      });
    }
  };

  return (
    <>
      {/* Language Selection */}
      <Card className="p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
          <i className="fas fa-language text-medical-blue mr-2"></i>
          Language Settings
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">From Language</label>
            <Select value={sourceLanguage} onValueChange={setSourceLanguage}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {languages.map((lang) => (
                  <SelectItem key={lang.code} value={lang.code}>
                    {lang.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">To Language</label>
            <Select value={targetLanguage} onValueChange={setTargetLanguage}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {languages.map((lang) => (
                  <SelectItem key={lang.code} value={lang.code}>
                    {lang.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        <div className="mt-4 flex justify-center">
          <Button 
            className="bg-medical-blue text-white hover:bg-blue-700"
            onClick={handleSwapLanguages}
          >
            <i className="fas fa-exchange-alt mr-2"></i>
            Swap Languages
          </Button>
        </div>
      </Card>

      {/* Translation Area */}
      <Card className="p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
          <i className="fas fa-comments text-medical-blue mr-2"></i>
          Real-time Translation
        </h2>
        
        {/* Input Section */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <label className="block text-sm font-medium text-gray-700">Input</label>
            <div className="flex space-x-2">
              <Button 
                size="sm"
                className="bg-healthcare-green text-white hover:bg-green-700"
                onClick={handleSpeechToggle}
                disabled={!isOnline}
              >
                <i className={`fas ${isListening ? 'fa-stop' : 'fa-microphone'} mr-1`}></i>
                {isListening ? 'Stop' : 'Record'}
              </Button>
              <Button 
                size="sm"
                variant="secondary"
                onClick={handleClear}
              >
                <i className="fas fa-trash mr-1"></i>
                Clear
              </Button>
            </div>
          </div>
          <Textarea 
            className="h-32 resize-none"
            placeholder="Type your message or use the Record button for speech input..."
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
          />
          
          {/* Speech Recognition Status */}
          {isListening && (
            <div className="mt-2 flex items-center space-x-2">
              <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
              <span className="text-sm text-red-600">Listening...</span>
            </div>
          )}
        </div>

        {/* Translation Button */}
        <div className="flex justify-center mb-6">
          <Button 
            size="lg"
            className="bg-medical-blue text-white px-8 py-3 text-lg font-semibold hover:bg-blue-700"
            onClick={handleTranslate}
            disabled={translateMutation.isPending || !isOnline}
          >
            <i className="fas fa-sync-alt mr-2"></i>
            {translateMutation.isPending ? 'Translating...' : 'Translate'}
          </Button>
        </div>

        {/* Output Section */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="block text-sm font-medium text-gray-700">Translation</label>
            <div className="flex space-x-2">
              <Button 
                size="sm"
                className="bg-urgent-orange text-white hover:bg-orange-600"
                onClick={handleSpeak}
                disabled={!translatedText || isSpeaking}
              >
                <i className="fas fa-volume-up mr-1"></i>
                {isSpeaking ? 'Speaking...' : 'Speak'}
              </Button>
              <Button 
                size="sm"
                variant="secondary"
                onClick={handleCopy}
                disabled={!translatedText}
              >
                <i className="fas fa-copy mr-1"></i>
                Copy
              </Button>
            </div>
          </div>
          <div className="w-full h-32 px-3 py-2 border border-gray-300 rounded-md bg-gray-50 overflow-y-auto">
            {translatedText ? (
              <>
                <div className="text-gray-900">{translatedText}</div>
                <div className="text-xs text-medical-gray mt-2 flex items-center">
                  <i className="fas fa-check-circle text-healthcare-green mr-1"></i>
                  Medical terminology verified
                </div>
              </>
            ) : (
              <div className="text-gray-400 italic">Translation will appear here...</div>
            )}
          </div>
          
          {/* Translation Status */}
          {translateMutation.isPending && (
            <div className="mt-2 flex items-center space-x-2">
              <div className="w-3 h-3 bg-medical-blue rounded-full animate-pulse"></div>
              <span className="text-sm text-medical-blue">Translating...</span>
            </div>
          )}
        </div>
      </Card>
    </>
  );
}
