import { useState, useEffect } from "react";
import TranslationInterface from "@/components/translation-interface";
import MedicalPhrasebook from "@/components/medical-phrasebook";
import ConversationHistory from "@/components/conversation-history";
import SystemStatus from "@/components/system-status";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

export default function Home() {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [sessionId] = useState(() => crypto.randomUUID());
  const { toast } = useToast();

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      toast({
        title: "Connection Restored",
        description: "You are now online. Translation services are available.",
      });
    };

    const handleOffline = () => {
      setIsOnline(false);
      toast({
        title: "Connection Lost", 
        description: "You are offline. Using cached phrases only.",
        variant: "destructive",
      });
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [toast]);

  const handleEmergencyMode = () => {
    toast({
      title: "Emergency Mode Activated",
      description: "Priority translation mode enabled for emergency situations.",
      variant: "destructive",
    });
  };

  const handleCallInterpreter = () => {
    toast({
      title: "Interpreter Service",
      description: "Connecting to professional interpreter service...",
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-md border-b-2 border-medical-blue">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <i className="fas fa-hospital-user text-2xl text-medical-blue"></i>
              <h1 className="text-xl font-bold text-gray-900">Medical Translation Assistant</h1>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className={`w-3 h-3 rounded-full ${isOnline ? 'bg-healthcare-green' : 'bg-medical-red'}`}></div>
                <span className="text-sm text-gray-600">{isOnline ? 'Online' : 'Offline'}</span>
              </div>
              <Button variant="ghost" size="sm">
                <i className="fas fa-cog text-lg text-medical-gray"></i>
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Translation Area */}
          <div className="lg:col-span-2 space-y-6">
            <TranslationInterface sessionId={sessionId} isOnline={isOnline} />
            <ConversationHistory sessionId={sessionId} />
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <Card className="p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                <i className="fas fa-bolt text-urgent-orange mr-2"></i>
                Quick Actions
              </h2>
              <div className="space-y-3">
                <Button 
                  className="w-full bg-medical-red text-white py-3 font-semibold hover:bg-red-700"
                  onClick={handleEmergencyMode}
                >
                  <i className="fas fa-exclamation-triangle mr-2"></i>
                  Emergency Mode
                </Button>
                <Button 
                  className="w-full bg-urgent-orange text-white py-2 hover:bg-orange-600"
                  onClick={handleCallInterpreter}
                >
                  <i className="fas fa-phone mr-2"></i>
                  Call Interpreter
                </Button>
              </div>
            </Card>

            <MedicalPhrasebook sessionId={sessionId} />
            <SystemStatus isOnline={isOnline} />
          </div>
        </div>
      </main>
    </div>
  );
}
