export interface TranslationResult {
  translatedText: string;
  originalText: string;
  sourceLanguage: string;
  targetLanguage: string;
}

export interface TranslationError {
  error: string;
  message: string;
  canRetry?: boolean;
}

export class TranslationService {
  private static instance: TranslationService;
  private offlinePhrases: Map<string, string> = new Map();

  private constructor() {
    this.initializeOfflinePhrases();
  }

  public static getInstance(): TranslationService {
    if (!TranslationService.instance) {
      TranslationService.instance = new TranslationService();
    }
    return TranslationService.instance;
  }

  private initializeOfflinePhrases() {
    // Common medical phrases for offline use
    const commonPhrases = [
      ['How are you feeling?', '¿Cómo se siente?'],
      ['Where does it hurt?', '¿Dónde le duele?'],
      ['Are you in pain?', '¿Siente dolor?'],
      ['Take this medication', 'Tome este medicamento'],
      ['Call for help', 'Pida ayuda'],
      ['Emergency', 'Emergencia'],
      ['Doctor', 'Doctor'],
      ['Nurse', 'Enfermera'],
      ['Hospital', 'Hospital'],
      ['Medicine', 'Medicina'],
    ];

    commonPhrases.forEach(([en, es]) => {
      this.offlinePhrases.set(`en:es:${en.toLowerCase()}`, es);
      this.offlinePhrases.set(`es:en:${es.toLowerCase()}`, en);
    });
  }

  public getOfflineTranslation(
    text: string, 
    sourceLanguage: string, 
    targetLanguage: string
  ): string | null {
    const key = `${sourceLanguage}:${targetLanguage}:${text.toLowerCase()}`;
    return this.offlinePhrases.get(key) || null;
  }

  public hasOfflineTranslation(
    text: string, 
    sourceLanguage: string, 
    targetLanguage: string
  ): boolean {
    return this.getOfflineTranslation(text, sourceLanguage, targetLanguage) !== null;
  }

  public getCachedPhrasesCount(): number {
    return this.offlinePhrases.size;
  }
}

export const translationService = TranslationService.getInstance();
