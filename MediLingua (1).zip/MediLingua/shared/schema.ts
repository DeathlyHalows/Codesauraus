import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const conversationEntries = pgTable("conversation_entries", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  originalText: text("original_text").notNull(),
  translatedText: text("translated_text").notNull(),
  sourceLanguage: text("source_language").notNull(),
  targetLanguage: text("target_language").notNull(),
  speaker: text("speaker").notNull(), // 'provider' or 'patient'
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  sessionId: text("session_id"), // Optional session grouping
});

export const translationRequests = pgTable("translation_requests", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  text: text("text").notNull(),
  sourceLanguage: text("source_language").notNull(),
  targetLanguage: text("target_language").notNull(),
  translatedText: text("translated_text"),
  status: text("status").notNull().default('pending'), // 'pending', 'completed', 'failed'
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertConversationEntrySchema = createInsertSchema(conversationEntries).omit({
  id: true,
  timestamp: true,
});

export const insertTranslationRequestSchema = createInsertSchema(translationRequests).omit({
  id: true,
  timestamp: true,
  translatedText: true,
  status: true,
});

export const translateTextSchema = z.object({
  text: z.string().min(1),
  sourceLanguage: z.string().min(2).max(5),
  targetLanguage: z.string().min(2).max(5),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type ConversationEntry = typeof conversationEntries.$inferSelect;
export type InsertConversationEntry = z.infer<typeof insertConversationEntrySchema>;
export type TranslationRequest = typeof translationRequests.$inferSelect;
export type InsertTranslationRequest = z.infer<typeof insertTranslationRequestSchema>;
export type TranslateTextRequest = z.infer<typeof translateTextSchema>;
