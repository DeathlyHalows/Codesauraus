import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { translateTextSchema, insertConversationEntrySchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Translation endpoint
  app.post("/api/translate", async (req, res) => {
    try {
      const data = translateTextSchema.parse(req.body);
      
      // Create translation request
      const translationRequest = await storage.createTranslationRequest({
        text: data.text,
        sourceLanguage: data.sourceLanguage,
        targetLanguage: data.targetLanguage,
      });

      try {
        // Use Google Translate API
        const googleTranslateApiKey = process.env.GOOGLE_TRANSLATE_API_KEY || process.env.GOOGLE_API_KEY || "";
        
        if (!googleTranslateApiKey) {
          throw new Error("Google Translate API key not configured");
        }

        const response = await fetch(
          `https://translation.googleapis.com/language/translate/v2?key=${googleTranslateApiKey}`,
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              q: data.text,
              source: data.sourceLanguage,
              target: data.targetLanguage,
              format: 'text',
            }),
          }
        );

        if (!response.ok) {
          throw new Error(`Translation API error: ${response.status}`);
        }

        const result = await response.json();
        const translatedText = result.data.translations[0].translatedText;

        // Update translation request with result
        await storage.updateTranslationRequest(translationRequest.id, translatedText, 'completed');

        res.json({
          translatedText,
          originalText: data.text,
          sourceLanguage: data.sourceLanguage,
          targetLanguage: data.targetLanguage,
        });

      } catch (error) {
        // Update translation request as failed
        await storage.updateTranslationRequest(translationRequest.id, '', 'failed');
        
        // Check if we're offline or API failed - return offline response
        res.status(503).json({
          error: 'Translation service unavailable',
          message: 'Please check your internet connection or try using offline mode with cached phrases.',
          canRetry: true,
        });
      }

    } catch (error) {
      res.status(400).json({ 
        error: 'Invalid request data',
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  // Conversation history endpoints
  app.post("/api/conversation", async (req, res) => {
    try {
      const data = insertConversationEntrySchema.parse(req.body);
      const entry = await storage.createConversationEntry(data);
      res.json(entry);
    } catch (error) {
      res.status(400).json({ 
        error: 'Invalid conversation entry data',
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  app.get("/api/conversation", async (req, res) => {
    try {
      const sessionId = req.query.sessionId as string | undefined;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
      
      const history = await storage.getConversationHistory(sessionId, limit);
      res.json(history);
    } catch (error) {
      res.status(500).json({ 
        error: 'Failed to fetch conversation history',
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  app.delete("/api/conversation", async (req, res) => {
    try {
      const sessionId = req.query.sessionId as string | undefined;
      await storage.clearConversationHistory(sessionId);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ 
        error: 'Failed to clear conversation history',
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  // Medical phrases endpoint (static data)
  app.get("/api/phrases", async (req, res) => {
    const medicalPhrases = {
      "Emergency": [
        "Are you having chest pain?",
        "Can you tell me where it hurts?",
        "Do you need immediate assistance?",
        "Are you allergic to any medications?",
        "We need to get you to the hospital."
      ],
      "Diagnosis": [
        "What symptoms are you experiencing?",
        "How long have you had these symptoms?",
        "Does the pain come and go?",
        "Can you describe the pain?",
        "Have you had this before?"
      ],
      "Symptoms": [
        "I feel dizzy.",
        "I have a fever.",
        "My throat is sore.",
        "I have a headache.",
        "My stomach hurts."
      ],
      "Consent": [
        "Do you understand the procedure?",
        "Do you consent to this treatment?",
        "Please sign here to give your consent.",
        "We need your permission to proceed.",
        "You have the right to refuse treatment."
      ]
    };

    res.json(medicalPhrases);
  });

  const httpServer = createServer(app);
  return httpServer;
}
