import { type User, type InsertUser, type ConversationEntry, type InsertConversationEntry, type TranslationRequest, type InsertTranslationRequest } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Conversation entries
  createConversationEntry(entry: InsertConversationEntry): Promise<ConversationEntry>;
  getConversationHistory(sessionId?: string, limit?: number): Promise<ConversationEntry[]>;
  clearConversationHistory(sessionId?: string): Promise<void>;
  
  // Translation requests
  createTranslationRequest(request: InsertTranslationRequest): Promise<TranslationRequest>;
  updateTranslationRequest(id: string, translatedText: string, status: 'completed' | 'failed'): Promise<TranslationRequest | undefined>;
  getTranslationHistory(limit?: number): Promise<TranslationRequest[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private conversationEntries: Map<string, ConversationEntry>;
  private translationRequests: Map<string, TranslationRequest>;

  constructor() {
    this.users = new Map();
    this.conversationEntries = new Map();
    this.translationRequests = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createConversationEntry(insertEntry: InsertConversationEntry): Promise<ConversationEntry> {
    const id = randomUUID();
    const entry: ConversationEntry = {
      ...insertEntry,
      id,
      timestamp: new Date(),
    };
    this.conversationEntries.set(id, entry);
    return entry;
  }

  async getConversationHistory(sessionId?: string, limit: number = 50): Promise<ConversationEntry[]> {
    const entries = Array.from(this.conversationEntries.values())
      .filter(entry => !sessionId || entry.sessionId === sessionId)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);
    return entries;
  }

  async clearConversationHistory(sessionId?: string): Promise<void> {
    if (sessionId) {
      for (const [id, entry] of this.conversationEntries.entries()) {
        if (entry.sessionId === sessionId) {
          this.conversationEntries.delete(id);
        }
      }
    } else {
      this.conversationEntries.clear();
    }
  }

  async createTranslationRequest(insertRequest: InsertTranslationRequest): Promise<TranslationRequest> {
    const id = randomUUID();
    const request: TranslationRequest = {
      ...insertRequest,
      id,
      timestamp: new Date(),
      translatedText: null,
      status: 'pending',
    };
    this.translationRequests.set(id, request);
    return request;
  }

  async updateTranslationRequest(id: string, translatedText: string, status: 'completed' | 'failed'): Promise<TranslationRequest | undefined> {
    const request = this.translationRequests.get(id);
    if (request) {
      const updatedRequest = { ...request, translatedText, status };
      this.translationRequests.set(id, updatedRequest);
      return updatedRequest;
    }
    return undefined;
  }

  async getTranslationHistory(limit: number = 50): Promise<TranslationRequest[]> {
    return Array.from(this.translationRequests.values())
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);
  }
}

export const storage = new MemStorage();
