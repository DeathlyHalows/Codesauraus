# Medical Translation Application

## Overview

This is a medical translation application designed to facilitate communication between healthcare providers and patients who speak different languages. The application provides real-time translation capabilities, predefined medical phrases, speech recognition, text-to-speech functionality, and conversation history tracking. It's built as a full-stack web application with offline capabilities for critical medical scenarios.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The client-side is built using **React 18** with **TypeScript** and **Vite** as the build tool. The application follows a component-based architecture with:

- **UI Framework**: Utilizes shadcn/ui components built on top of Radix UI primitives for accessible, customizable interface components
- **Styling**: Tailwind CSS with a custom medical theme featuring healthcare-specific color variables
- **State Management**: React Query (TanStack Query) for server state management and caching
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod validation for type-safe form management

### Backend Architecture
The server is built with **Express.js** and **TypeScript** using an ESM module system:

- **API Design**: RESTful endpoints for translation, conversation management, and phrase retrieval
- **Request/Response Flow**: Centralized error handling and logging middleware with request duration tracking
- **Development Setup**: Vite middleware integration for hot module replacement in development

### Data Storage Solutions
The application uses a **PostgreSQL** database with **Drizzle ORM** for type-safe database operations:

- **Schema Design**: Three main entities - users, conversation entries, and translation requests
- **Database Access**: Neon Database serverless PostgreSQL with connection pooling
- **Migration Strategy**: Drizzle Kit for schema migrations and database management
- **Fallback Storage**: In-memory storage implementation for development and testing scenarios

### Authentication and Authorization
Currently implements a basic user system with:

- **User Management**: Username/password authentication with unique constraints
- **Session Handling**: Express sessions with PostgreSQL session store using connect-pg-simple
- **Future Considerations**: Framework in place for role-based access control and healthcare provider verification

### External Service Integrations

#### Translation Services
- **Primary Provider**: Google Translate API for real-time translation between multiple languages
- **Offline Fallback**: Local phrase cache with common medical translations stored in-memory
- **Error Handling**: Graceful degradation to cached phrases when API is unavailable

#### Browser APIs
- **Speech Recognition**: Web Speech API for voice input with language-specific recognition
- **Text-to-Speech**: Web Speech Synthesis API for audio output with medical-appropriate speech rates
- **Offline Detection**: Navigator online/offline events for connection state management

#### Development Tools
- **Replit Integration**: Custom Vite plugins for Replit development environment
- **Error Tracking**: Runtime error overlay for development debugging
- **Code Mapping**: Source map support for debugging in production builds

### Key Design Decisions

**Offline-First Approach**: The application caches common medical phrases locally to ensure critical communication remains possible during network outages, which is essential in healthcare settings.

**Medical-Specific UI**: Custom Tailwind theme with healthcare colors and iconography from Font Awesome to create an interface appropriate for medical environments.

**Real-time Features**: Conversation history updates every 5 seconds and speech synthesis provides immediate audio feedback to facilitate rapid communication during medical emergencies.

**Type Safety**: Comprehensive TypeScript implementation with Zod schemas for runtime validation ensures data integrity across the entire application stack.

**Modular Architecture**: Clear separation between client/server/shared code with path aliases for maintainable imports and component organization.